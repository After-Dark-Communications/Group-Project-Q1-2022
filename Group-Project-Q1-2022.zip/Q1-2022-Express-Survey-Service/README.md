# Q1-2022-Express-Survey-Service
Survey Service for group project made in Express

### After cloning repo
```npm install``` to install dependencies

Add ```.env``` file to root

### Commands
```npm run start``` to start server

```npm run dev``` to start server with hot-reload

```npm run swagger-autogen``` to generate swagger documentation

```npm run test``` to run tests
