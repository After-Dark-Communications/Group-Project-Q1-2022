export const surveys = [
    {
      id: 1,
      title: "Survey1",
      answer1: "Not so good",
      answer2: " Really nice",
      answer3: "Could be better",
    },
    {
        id: 2,
        title: "Survey2",
        answer1: "Not so good",
        answer2: " Really nice",
        answer3: "Could be better",
      },
      {
        id: 3,
        title: "Survey3",
        answer1: "Not so good",
        answer2: " Really nice",
        answer3: "Could be better",
      },
      {
        id: 4,
        title: "Survey4",
        answer1: "Not so good",
        answer2: " Really nice",
        answer3: "Could be better",
      },
      {
        id: 5,
        title: "Survey5",
        answer1: "Not so good",
        answer2: " Really nice",
        answer3: "Could be better",
      },
      {
        id: 6,
        title: "Survey6",
        answer1: "Not so good",
        answer2: " Really nice",
        answer3: "Could be better",
      },
  ];